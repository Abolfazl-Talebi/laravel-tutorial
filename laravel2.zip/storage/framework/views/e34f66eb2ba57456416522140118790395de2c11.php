<?php $__env->startSection('content'); ?>
<section id="intro2" class="clearfix"></section>

<main class="container main2">
  <nav aria-label="breadcrumb ">
    <ol class="breadcrumb bgcolor">
      <li class="breadcrumb-item"><a href="#">خانه</a></li>
      <li class="breadcrumb-item active" aria-current="page">فعالسازی حساب کاربری</li>
    </ol>
  </nav>




  <?php echo $__env->make('front.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="d-flex justify-content-center">


    <div class="card">
      برای فعالسازی حساب کاربری خود روی دکمه زیر کلیک نمایید تا ایمیل فعالسازی برای شما ارسال شود
      <hr>
      <?php if(session('resent')): ?>

      <div class="alert alert-success">یک ایمیل برای فعالسازی حساب کاربری شما ارسال شد.ایمیل خود را بررسی و روی لینک
        فعالسازی حساب کاربری کلیک نمایید</div>

      <?php endif; ?>
      <form action="<?php echo e(route('verification.resend')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button>ارسال ایمیل فعالسازی</button>
      </form>

    </div>


  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp\www\laravel2\resources\views/front/auth/verify.blade.php ENDPATH**/ ?>