<?php $__env->startSection('content'); ?>
<section id="intro2" class="clearfix"></section>

<main class="container main2">
  <nav aria-label="breadcrumb ">
    <ol class="breadcrumb bgcolor">
      <li class="breadcrumb-item"><a href="#">خانه</a></li>
      <li class="breadcrumb-item active" aria-current="page">مطالب</li>
    </ol>
  </nav>






  <div class="d-flex justify-content-center">

    <div class="row">

      <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-sm-3">
        <img src="<?php echo '/photos/1/thumbs/'.basename($article->image)?>" alt="">
        <h3><a href="<?php echo e(route('article',$article->slug)); ?>"><?php echo e($article->name); ?></a></h3>
        <div>
          <ul>
            <li>نویسنده:<?php echo e($article->user->name); ?></li>
            <li>تاریخ: <?php echo jdate($article->created_at)->format('%d-%m-%Y'); ?></li>
            <li>بازدید: <?php echo e($article->hit); ?></li>
          </ul>

        </div>
        <p><?php echo mb_substr(strip_tags($article->description),0,200,'UTF8').'. . .' ; ?></p>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




    </div>



  </div>
  <?php echo e($articles->links()); ?>

</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp\www\laravel2\resources\views/front/articles.blade.php ENDPATH**/ ?>