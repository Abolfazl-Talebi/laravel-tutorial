<?php $__env->startSection('title'); ?>
آموزش لاراول - پنل مدیریت
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="main-panel">
    <div class="content-wrapper">
        <!-- Page Title Header Starts-->
        <div class="row page-title-header">
            <div class="col-12">
                <div class="page-header">
                    <h4 class="page-title">پنل مدیریت</h4>
                </div>
            </div>

        </div>
        <!-- Page Title Header Ends-->


        <div class="row">

            صفحه نخست ادمین - نمایش گزارشات
        </div>




    </div>
    <!-- content-wrapper ends -->
    <?php echo $__env->make('back.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp\www\laravel2\resources\views/back/main.blade.php ENDPATH**/ ?>