<?php $__env->startSection('title'); ?>
پنل مدیریت - مدیریت کاربران
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="main-panel">
    <div class="content-wrapper">
        <!-- Page Title Header Starts-->
        <div class="row page-title-header">
            <div class="col-12">
                <div class="page-header">
                    <h4 class="page-title">مدیریت کاربران</h4>
                </div>
            </div>

        </div>
        <!-- Page Title Header Ends-->


        <div class="row">


            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <?php echo $__env->make('back.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>نام</th>
                                    <th>ایمیل</th>
                                    <th>تلفن</th>
                                    <th>نقش</th>
                                    <th>وضعیت</th>
                                    <th>مدیریت</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                <?php switch($user->role):
                                case (1): ?>
                                <?php $role = 'مدیر' ?>
                                <?php break; ?>
                                <?php case (2): ?>
                                <?php $role = 'کاربر' ?>
                                <?php break; ?>
                                <?php default: ?>
                                <?php endswitch; ?>


                                <?php switch($user->status):
                                case (1): ?>
                                <?php
                                $url = route('admin.user.status',$user->id);
                                $status = '<a href="'.$url.'" class="badge badge-success">فعال</a>' ?>
                                <?php break; ?>
                                <?php case (0): ?>
                                <?php
                                $url = route('admin.user.status',$user->id);
                                $status = '<a href="'.$url.'" class="badge badge-warning">غیر فعال</a>' ?>
                                <?php break; ?>
                                <?php default: ?>
                                <?php endswitch; ?>


                                <tr>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->phone); ?></td>
                                    <td><?php echo e($role); ?></td>
                                    <td><?php echo $status; ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.profile',$user->id)); ?>"
                                            class="badge badge-success">ویرایش</a>
                                        <a href="<?php echo e(route('admin.user.delete',$user->id)); ?>"
                                            onclick="return confirm('آیا آیتم مورد نظر حذف شود');"
                                            class="badge badge-warning"> حذف </a>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>

                    </div>
                    <?php echo e($users->links()); ?>

                </div>
            </div>


        </div>




    </div>
    <!-- content-wrapper ends -->
    <?php echo $__env->make('back.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp\www\laravel2\resources\views/back/users/users.blade.php ENDPATH**/ ?>