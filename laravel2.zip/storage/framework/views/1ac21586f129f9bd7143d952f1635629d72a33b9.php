<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

</head>

<body dir="rtl">
    با سلام خدمت شما کاربر گرامی

    <p>کامنت شما دریافت شد با جزئیات زیر:</p>
    <p>
        نام ارسال کننده: <?php echo e($userName); ?>

        <br>
        متن کامنت شما: <?php echo e($commentBody); ?>

        <br>
        ارسال شده برای مطلب: <?php echo e($articleTitle); ?>




    </p>
    <hr>
    کامنت شما پس از تایید مدیریت سایت ، نمایش داده میشود
    <hr>
    <a href="http:\\alefyar.com">وب سایت الف یار</a>
    این ایمیل به صورت خودکار ارسال شده است و از پاسخگویی به آن خودداری بفرمایید
</body>

</html><?php /**PATH G:\wamp\www\laravel2\resources\views/mails/comment.blade.php ENDPATH**/ ?>