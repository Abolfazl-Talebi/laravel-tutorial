<?php $__env->startSection('content'); ?>
<section id="intro2" class="clearfix"></section>

<main class="container main2">
  <nav aria-label="breadcrumb ">
    <ol class="breadcrumb bgcolor">
      <li class="breadcrumb-item"><a href="#">خانه</a></li>
      <li class="breadcrumb-item" aria-current="page">مطالب</li>
      <li class="breadcrumb-item active" aria-current="page"><?php echo e($article->name); ?></li>
    </ol>
  </nav>






  <div class="d-flex justify-content-center">

    <div class="container">

      <div>
        <h1><?php echo e($article->name); ?></h1>
      </div>
      <div>

        <ul>
          <li>نویسنده:<?php echo e($article->user->name); ?></li>
          <li>تاریخ: <?php echo jdate($article->created_at)->format('%d-%m-%Y'); ?></li>
          <li>بازدید: <?php echo e($article->hit); ?></li>
        </ul>
      </div>
      <p>
        <?php echo $article->description; ?>

      </p>

    </div>



  </div>

  <div>
    <?php echo $__env->make('front.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <hr>
    <form action="<?php echo e(route('comment.store',$article->slug)); ?>" class="form-group" method="POST">
      <?php echo csrf_field(); ?>
      <div class="form-row">

        <?php if(auth()->guard()->check()): ?>
        <div class="form-group col-md-6">
          <label for="name">نام:</label>
          <input class="form-control" type="text" name="name" value="<?php echo e(Auth::user()->name); ?>" readonly>
        </div>
        <div class="form-group col-md-6">
          <label for="name">ایمیل:</label>
          <input class="form-control" type="text" name="email" value="<?php echo e(Auth::user()->email); ?>" readonly>
        </div>
      </div>
      <?php else: ?>
      <div class="form-group col-md-6">
        <label for="name">نام:</label>
        <input class="form-control" type="text" name="name">
      </div>
      <div class="form-group col-md-6">
        <label for="name">ایمیل:</label>
        <input class="form-control" type="text" name="email">
      </div>
  </div>
  <?php endif; ?>



  <div class="form-group">
    <label for="body">متن نظر شما</label>
    <textarea class="form-control" name="body" id="" cols="30" rows="10"></textarea>
  </div>

  <div class="form-group">
    <label for="recaprcha">تصویر امنیتی</label>
    <?php echo htmlFormSnippet(); ?>


  </div>




  <button class="btn btn-primary" type="submit">ارسال نظر</button>

  </form>
  </div>

  <div>
    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div>
      <ul>
        <li>نویسنده: <?php echo e($comment->name); ?></li>
        <li>ایمیل: <?php echo e($comment->email); ?></li>

      </ul>
      <div>
        متن نظر<?php echo e($comment->body); ?>

      </div>
    </div>
    <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp\www\laravel2\resources\views/front/article.blade.php ENDPATH**/ ?>