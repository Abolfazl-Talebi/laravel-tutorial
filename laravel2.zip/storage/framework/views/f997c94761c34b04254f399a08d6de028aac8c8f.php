<?php $__env->startSection('title'); ?>
پنل مدیریت - مدیریت مطالب
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="main-panel">
    <div class="content-wrapper">
        <!-- Page Title Header Starts-->
        <div class="row page-title-header">
            <div class="col-12">
                <div class="page-header">
                    <h4 class="page-title">مدیریت مطالب</h4>

                </div>
                <div class=" float-right">
                    <a href="<?php echo e(route('admin.articles.create')); ?>" class="btn btn-success btn-fw  ">مطلب جدید</a>
                </div>
            </div>

        </div>
        <!-- Page Title Header Ends-->


        <div class="row">


            <div class="col-lg-12 grid-margin stretch-card">

                <div class="card">

                    <div class="card-body">
                        <?php echo $__env->make('back.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>نام</th>
                                    <th>نا مستعار - Slug</th>
                                    <th>نویسنده</th>
                                    <th>دسته بندی</th>
                                    <th>بازدید</th>
                                    <th>وضعیت</th>
                                    <th>مدیریت</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php switch($article->status):
                                case (1): ?>
                                <?php
                                $url = route('admin.articles.status',$article->id);
                                $status = '<a href="'.$url.'" class="badge badge-success">فعال</a>' ?>
                                <?php break; ?>
                                <?php case (0): ?>
                                <?php
                                $url = route('admin.articles.status',$article->id);
                                $status = '<a href="'.$url.'" class="badge badge-warning">غیر فعال</a>' ?>
                                <?php break; ?>
                                <?php default: ?>
                                <?php endswitch; ?>




                                <tr>
                                    <td><?php echo e($article->name); ?></td>
                                    <td><?php echo e($article->slug); ?></td>
                                    <td><?php echo e($article->user->name); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $article->categories()->pluck('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge badge-warning"><?php echo e($category); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                    </td>
                                    <td><?php echo e($article->hit); ?></td>
                                    <td><?php echo $status; ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.articles.edit',$article->id)); ?>"
                                            class="badge badge-success">ویرایش</a>
                                        <a href="<?php echo e(route('admin.articles.destroy',$article->id)); ?>"
                                            onclick="return confirm('آیا آیتم مورد نظر حذف شود');"
                                            class="badge badge-warning"> حذف </a>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>

                    </div>
                    <?php echo e($articles->links()); ?>

                </div>
            </div>


        </div>




    </div>
    <!-- content-wrapper ends -->
    <?php echo $__env->make('back.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp\www\laravel2\resources\views/back/articles/articles.blade.php ENDPATH**/ ?>