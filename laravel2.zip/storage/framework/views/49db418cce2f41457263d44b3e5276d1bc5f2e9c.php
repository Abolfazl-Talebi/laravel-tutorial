<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>Rapid Bootstrap Template</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="front/img/favicon.png" rel="icon">
  <link href="front/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link
    href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700"
    rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="<?php echo e(url('/front/css/app.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(url('/front/css/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(url('/front/css/ionicons/css/ionicons.min.css')); ?>" rel="stylesheet">


  <?php echo htmlScriptTagJsApi(['lang'=>'fa']); ?>


</head>

<body dir="rtl">

  <?php echo $__env->make('front.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->yieldContent('content'); ?>

  <?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <script src="<?php echo e(url('/front/js/app.js')); ?>"></script>
  <script src="<?php echo e(url('/front/js/easing/easing.min.js')); ?>"></script>

</body>

</html><?php /**PATH G:\wamp\www\laravel2\resources\views/front/index.blade.php ENDPATH**/ ?>