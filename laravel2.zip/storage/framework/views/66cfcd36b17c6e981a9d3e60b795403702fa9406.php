<?php $__env->startSection('title'); ?>
پنل مدیریت - مدیریت نمونه کارها
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="main-panel">
    <div class="content-wrapper">
        <!-- Page Title Header Starts-->
        <div class="row page-title-header">
            <div class="col-12">
                <div class="page-header">
                    <h4 class="page-title">مدیریت نمونه کارها</h4>

                </div>
                <div class=" float-right">
                    <a href="<?php echo e(route('admin.portfolios.create')); ?>" class="btn btn-success btn-fw  ">نمونه کار جدید</a>
                </div>
            </div>

        </div>
        <!-- Page Title Header Ends-->


        <div class="row">


            <div class="col-lg-12 grid-margin stretch-card">

                <div class="card">

                    <div class="card-body">
                        <?php echo $__env->make('back.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>نام</th>
                                    <th>تگ</th>
                                    <th>لینک</th>
                                    <th>توضیحات</th>
                                    <th>مدیریت</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><?php echo e($portfolio->name); ?></td>
                                    <td><?php echo e($portfolio->tag); ?></td>
                                    <td><?php echo e($portfolio->link); ?></td>
                                    <td><?php echo e($portfolio->description); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.portfolios.edit',$portfolio->id)); ?>"
                                            class="badge badge-success">ویرایش</a>
                                        <a href="<?php echo e(route('admin.portfolios.destroy',$portfolio->id)); ?>"
                                            onclick="return confirm('آیا آیتم مورد نظر حذف شود');"
                                            class="badge badge-warning"> حذف </a>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>

                    </div>
                    <?php echo e($portfolios->links()); ?>

                </div>
            </div>


        </div>




    </div>
    <!-- content-wrapper ends -->
    <?php echo $__env->make('back.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp\www\laravel2\resources\views/back/portfolios/portfolios.blade.php ENDPATH**/ ?>