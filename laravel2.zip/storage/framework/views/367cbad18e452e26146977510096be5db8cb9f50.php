<!--==========================
        Portfolio Section
      ============================-->
<section id="portfolio" class="section-bg">
    <div class="container">

        <header class="section-header">
            <h3 class="section-title">نمونه کارها</h3>
        </header>

        <div class="row">
            <div class="col-lg-12">
                <ul id="portfolio-flters">
                    <li data-filter="*" class="filter-active">همه</li>
                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li data-filter=".filter-<?php echo e($item->tag); ?>"><?php echo e($item->tag); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </ul>
            </div>
        </div>

        <div class="row portfolio-container">


            <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 portfolio-item filter-<?php echo e($item->tag); ?>">
                <div class="portfolio-wrap">
                    <img src="<?php echo e($item->image); ?>" class="img-fluid" alt="">
                    <div class="portfolio-info">
                        <h4><a href="<?php echo e($item->link); ?>"><?php echo e($item->name); ?></a></h4>
                        <p><?php echo e($item->description); ?></p>
                        <div>
                            <a href="<?php echo e($item->image); ?>" data-lightbox="portfolio" data-title="App 1" class="link-preview"
                                title="Preview"><i class="ion ion-eye"></i></a>
                            <a href="<?php echo e($item->link); ?>" class="link-details" title="More Details"><i
                                    class="ion ion-android-open"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>

    </div>
</section><!-- #portfolio --><?php /**PATH G:\wamp\www\laravel2\resources\views/front/portfolio.blade.php ENDPATH**/ ?>