# <div dir="rtl">سورس دوره ی آموزشی لاراول در سایت الف یار Alefyar.com</div>
## برای دانلود دوره ی رایگان لاراول به لینکهای زیر میتوانید مراجعه نمایید
* [آموزش رایگان لاراول](http://www.alefyar.com/laravel-tutorial)
* [لاراول چیست](http://www.alefyar.com/what-is-laravel)
* [آموزش رایگان php](http://www.alefyar.com/php-oop-pdo-turorial-section1)
<h3 dir="rtl"> مراحل نصب</h3>
<ul dir="rtl">
<li>یک فولدر ایجاد کنید</li>
<li>در خط فرمان تایپ کنید composer create-project abolfazl-talebi/laravel-tutorial</li>
<li>تمام فایلهای دوره برای شما در فولدر ایجاد شده قرار میگیرد</li>
<li>اکنون برای نصب پکیج های کامپوزر دستور زیر را وارد کنید</li>
<li>composer install</li>
<li>اکنون برای نصب node_module دستور زیر را وارد کنید</li>
<li>npm install</li>
<li>اکنون اطلاعات دیتابیس خود را در فایل .env تنظیم کنید و سپس migrate را انجام دهید</li>
</ul>
