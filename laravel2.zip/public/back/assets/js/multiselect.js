document.getElementById('output').innerHTML = location.search;
$(".chosen-select").chosen();