<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

</head>

<body dir="rtl">
    با سلام خدمت شما کاربر گرامی

    <p>کامنت شما دریافت شد با جزئیات زیر:</p>
    <p>
        نام ارسال کننده: {{$userName}}
        <br>
        متن کامنت شما: {{$commentBody}}
        <br>
        ارسال شده برای مطلب: {{$articleTitle}}



    </p>
    <hr>
    کامنت شما پس از تایید مدیریت سایت ، نمایش داده میشود
    <hr>
    <a href="http:\\alefyar.com">وب سایت الف یار</a>
    این ایمیل به صورت خودکار ارسال شده است و از پاسخگویی به آن خودداری بفرمایید
</body>

</html>